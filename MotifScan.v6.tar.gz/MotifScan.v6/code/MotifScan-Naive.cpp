#include <iostream>

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <map>

#include "typedefs.h"
#include "util.h"
#include "sequence.h"
#include "SequenceWtMxToolbox.h"
#include "SequenceWtMxToolbox.NaiveHelper.h"
#include "fastafile.h"

extern float SequenceWtMxToolboxNaive::thresholdFactor;
extern float SequenceWtMxToolboxNaive::llrthreshold;

int main(int argc, char **argv)
{
  if (argc < 4) {
    printf("usage: %s <fastafile> <wtmxfile1> <threshold> [-b <background file>]\n",argv[0]);
    exit(1);
  }
	
  srandom((unsigned int)time(NULL));
  srand48((unsigned int)time(NULL));
	
  char *fastafile = argv[1];
  FastaFile *file = new FastaFile();
  file->ReadFasta(fastafile);
	
  Sequence **seqs = file->_sequences;
  int numSeqs = file->Size();
	
  char *wmc1file = argv[2];
  WtMxCollection *wmc1 = new WtMxCollection(wmc1file);
  if (wmc1->Size() != 1) { 
    printf("Can only scan for one motif at a time: file %s should have only one PWM\n");
    exit(1);
  }	
	
  float thresholdFactor = atof(argv[3]);
	
  // Read in the optional arguments
  int argbase = 4;
  struct Options *opt = ReadOptionalArguments(argbase, argc, argv);
	
  // create background, if required to be global
  WtMx *bkgwm = NULL;
  Sequence **bkg_seq = new Sequence *[1];
  if (opt->bkg_file != NULL) {
    bkg_seq[0] = new Sequence(opt->bkg_file);
    bkgwm = SequenceWtMxToolbox::TrainBackground(bkg_seq,1,opt->markov_order);
    delete bkg_seq[0];
  }
  delete [] bkg_seq;
	
  // cache probabilities for each sequence
  // store local bkg pwms (after creating them) if needed
  for (int i=0; i<numSeqs; i++) {
    // fprintf(stderr,"Caching sequence %d\n",i);
    // SequenceWtMxToolbox::CacheSubsequenceProbabilities(seqs[i],wmc1,bkgwm,opt->markov_order);
  }
	
  char *name = new char[1024];
  // process 
  int *matchposlist = new int[Sequence::MAX_SEQ_LENGTH];
  Sequence **seq = new Sequence *[1];
  for (int seqnum=0; seqnum < numSeqs; seqnum++) {
    seq[0] = seqs[seqnum];		
    seq[0]->Name(name);
		
    // if the promoter is very small or highly masked, then score = 0
    if (seq[0]->RealLength() < 20) {
      DTYPE count = 0; DTYPE bestllr = 0;
      printf("%d\t%s\t%d\t%.2f\n",seqnum,name,count,bestllr);
      continue;
    }
		
    opt->markov_order = 0;

    // cache probabilities for this sequence
    // store local bkg pwms (after creating them) if needed
    SequenceWtMxToolboxNaive::thresholdFactor = thresholdFactor;
    SequenceWtMxToolboxNaive::CacheSubsequenceProbabilities(seq[0],wmc1,bkgwm,opt->markov_order);

    // now check occursat at every position of sequence
    int count = 0;
    int wm_len = wmc1->WM(0)->Length();
    int matchposctr = 0;
    DTYPE LRsum = 0;
    DTYPE bestllr = 0;
    int qlen = seq[0]->Length();
    for (int l=0; l<= qlen-1-wm_len+1; l++) {
      DTYPE llr;
      if (seq[0]->OccursAt(l, wmc1->WM(0), &llr)) {
	count++;
	matchposlist[matchposctr++] = l;
      }
      if (llr > bestllr) bestllr = llr;
    }
    fprintf(stderr,"Threshold: %g\n",SequenceWtMxToolboxNaive::llrthreshold);
    if (!opt->naive_score)
      printf("%d\t%s\t%d\t%.2f\t-",seqnum,name,count,bestllr);
    else {
      // DTYPE LRsum = seq[0]->SumLRatSites(wmc1->WM(0));
      DTYPE SSsum = seq[0]->SumSiteStrength(wmc1->WM(0));
      printf("%d\t%s\t%d\t%.2f\t%.2f",seqnum,name,count,bestllr,SSsum);	
    }
    for (int m=0; m<matchposctr; m++) printf("\t%d",matchposlist[m]);
    printf("\n");
    
    // clean up
    fprintf(stderr,"Done processing seq number %d\n",seqnum);
    SequenceWtMxToolbox::DeleteCacheSubsequenceProbabilities(seq[0]);		
  }
  delete [] name;
  delete [] matchposlist;
}

