#ifndef _sequencewtmxfunction_naive_h_
#define _sequencewtmxfunction_naive_h_

#include <vector>
using namespace std;

#include "SequenceWtMxToolbox.h"

class SequenceWtMxToolboxNaive : public SequenceWtMxToolbox {
 public:
  static float  thresholdFactor; // this times the max LLR score is the RE threshold
  static float  llrthreshold;    // this will be set by the CacheSubsequenceProbabilities
  static void CacheSubsequenceProbabilities(Sequence *seq, WtMxCollection *wmc, WtMx *bkgwm, int markov_order);
  static float MaxLLR(WtMx *wm, WtMx *bkgwm);
};

#endif
