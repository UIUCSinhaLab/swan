#include "SequenceWtMxToolbox.h"
#include <math.h>


////////////////////////////////////////////////////////
// Implementation of the probabilitycache data structure
////////////////////////////////////////////////////////

SequenceWtMxToolbox::probabilitycache::probabilitycache()
{
	_prob = NULL;
	_llr = NULL;
	_occursat = NULL;
	_sumlratsites = NULL;
	_sumsitestrength = NULL;
	_wms = NULL;
	_numWM = 0;
	_length = 0;
}

SequenceWtMxToolbox::probabilitycache& SequenceWtMxToolbox::probabilitycache::operator=(const probabilitycache &pc)
{
	if (this == &pc) return *this;
	Destroy();
	Copy(pc);
}

SequenceWtMxToolbox::probabilitycache::probabilitycache(const probabilitycache &pc)
{
	Copy(pc);
}

SequenceWtMxToolbox::probabilitycache::~probabilitycache()
{
	Destroy();
}

void SequenceWtMxToolbox::probabilitycache::Copy(const probabilitycache &pc)
{
	const probabilitycache *pcptr = &pc;
	if (pcptr==NULL) {
		printf("Error: copy called for null probabilitycache\n");
		exit(1);
	}
	
	int i;
	_numWM = pcptr->_numWM;
	_length = pcptr->_length;
	
	if (pcptr->_wms) {
		_wms = new WtMx*[_numWM];
		for (i=0; i<_numWM; i++) 
			_wms[i] = pcptr->_wms[i];
	}
	else _wms = NULL;
	
	if (pcptr->_prob) {
		_prob = new DTYPE  *[_numWM];
		_occursat = new bool  *[_numWM];
		_sumlratsites = new DTYPE[_numWM];
		_sumsitestrength = new DTYPE[_numWM];
		for (int j=0; j<_numWM; j++) {
			_prob[j] = new DTYPE [_length];
			_occursat[j] = new bool [_length];
			_sumlratsites[j] = pcptr->_sumlratsites[j];
			_sumsitestrength[j] = pcptr->_sumsitestrength[j];
			for (int l=0; l<_length; l++) {
				_prob[j][l] = pcptr->_prob[j][l];
				_occursat[j][l] = pcptr->_occursat[j][l];
			}
		}
	}
	else {
		_prob = NULL;
		_occursat = NULL;
		_sumlratsites = NULL;
		_sumsitestrength = NULL;
	}
	if (pcptr->_llr) {
	  _llr = new DTYPE  *[_numWM];
	  for (int j=0; j<_numWM; j++) {
	    _llr[j] = new DTYPE [_length];
	    for (int l=0; l<_length; l++) {	    
	      _llr[j][l] = pcptr->_llr[j][l];
	    }
	  }
	}
	else _llr = NULL;
}

void SequenceWtMxToolbox::probabilitycache::Destroy()
{
	if (_prob) {
		for (int j=0; j<_numWM; j++) { 
		  if (_prob[j]) { delete [] _prob[j]; }
		  if (_occursat[j] && (j != _numWM -1)) { delete [] _occursat[j]; }// skip occurs at optimization of background
		}
		delete [] _prob;
		_prob = NULL;
		delete [] _occursat;
		_occursat = NULL;
	}
	if (_llr) {
		for (int j=0; j<_numWM; j++) { 
		  if (_llr[j]) { delete [] _llr[j]; }
		}
		delete [] _llr;
		_llr = NULL;
	}
	if (_sumlratsites) {
		delete [] _sumlratsites;
		_sumlratsites = NULL;
	}
	if (_sumsitestrength) {
		delete [] _sumsitestrength;
		_sumsitestrength = NULL;
	}
	
	if (_wms) {
		delete [] _wms;
		_wms = NULL;
	}
	
}

///////////////////////////////////////////////////////////////////////////////////////////////
// Implementation of the static methods that create/destroy the probabilitycache for a sequence
///////////////////////////////////////////////////////////////////////////////////////////////

void SequenceWtMxToolbox::CacheSubsequenceProbabilities(Sequence *seq, WtMxCollection *wmc, WtMx *bkgwm, int markov_order)
// bkgwm may be null
{
	struct probabilitycache *oldpc = (struct probabilitycache *)(seq->GetUserData());
	// when asked to cache probabilities for a sequence, destroy any old cache that may be present
	if (oldpc != NULL) delete oldpc;
	seq->SetUserData(NULL);
	
	if (bkgwm == NULL) { // then create background for this sequence
		Sequence **bkg_seq = new Sequence *[1];
		bkg_seq[0] = seq;
		bkgwm = TrainBackground(bkg_seq,1,markov_order);
		delete [] bkg_seq;
	}
	
	// create the array of WtMx* from the given WtMxCollection
	int numWM = wmc->Size();
	WtMx **wms = new WtMx *[(numWM+(bkgwm?1:0))];
	for (int i=0; i<numWM; i++) {
		WtMx *wm = wmc->WM(i);
		wms[i] = wm;
#ifdef _OPTIMIZE_WMINDEX
		wm->SetUserData(i);
#endif
	}
	if (bkgwm) {
		wms[numWM] = bkgwm;
#ifdef _OPTIMIZE_WMINDEX
		bkgwm->SetUserData(numWM);
#endif
		numWM++;
	}
	
	int length = seq->Length();
	
	// create the actual array of subsequence probabilities
	DTYPE NEGINF = log(0);
	DTYPE  **prob = new DTYPE  *[numWM];
	for (int j=0; j<numWM; j++) {
		int wm_len = wms[j]->Length();
		DTYPE repvalthresh = wms[j]->GetREPvalThresh();
		DTYPE rethresh = wms[j]->GetREThresh();
		prob[j] = new DTYPE  [length];

		for (int l=0; l<length-wm_len+1; l++) {
			DTYPE f_prob = SequenceWtMxToolbox::ComputeSequenceProbability(seq, l, l+wm_len-1, wms[j], 0);
			DTYPE r_prob = SequenceWtMxToolbox::ComputeSequenceProbability(seq, l, l+wm_len-1, wms[j], 1);
			if (repvalthresh >= 0) {
				if (f_prob < rethresh) { f_prob = NEGINF; } else { 
					f_prob -= log(repvalthresh); 
				}
				if (r_prob < rethresh) { r_prob = NEGINF; } else { 
					r_prob -= log(repvalthresh); 
				}
			}
			prob[j][l] = log((exp(f_prob)+exp(r_prob))/2);
		}
	}
	
	// use the above probabilities to flag positions where motifs occur
	bool **occursat = new bool *[numWM];
 	for (int j=0; j<wmc->Size(); j++) {
		int wm_len = wms[j]->Length();
		occursat[j] = new bool  [length];
		for (int l=0; l<length-wm_len+1; l++) {      
			if (!bkgwm) occursat[j][l] = true; 
			else {
				DTYPE bkgprob = 0;
				for (int p=0; p<wm_len; p++) bkgprob += prob[numWM-1][l+p];
				if (prob[j][l] > (bkgprob-log(COMPARE_BKG_SCALED_BY))) {
					occursat[j][l] = true;
					// fprintf(stderr,"Site at %d\n",l);				
				}
				else occursat[j][l] = false;
			}
		}
	}
	
	// create a cache object
	struct probabilitycache *pc = new struct probabilitycache;
	pc->_numWM = numWM;
	pc->_length = length;
	pc->_wms = wms;
	pc->_prob = prob;
	pc->_llr = NULL;
	pc->_occursat = occursat;
	pc->_sumlratsites = NULL;
	pc->_sumsitestrength = NULL;

	// store this cache in the Sequence object
	seq->SetUserData((void *)pc);
}

void SequenceWtMxToolbox::DeleteCacheSubsequenceProbabilities(Sequence *seq)
{
	struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
	if (pc == NULL) return;
	delete pc;
	seq->SetUserData(NULL);
}

//////////////////////////////////////////////////////////////////////////
// Utility Method for creating weight matrix (background) out of sequences
//////////////////////////////////////////////////////////////////////////

WtMx *SequenceWtMxToolbox::TrainBackground(Sequence **sequences, int numSequence, int Markov_Order)
{
	WtMx *bkgwm;
	
	if (Markov_Order == 0) {
		float **bkgmat = new float *[4];
		for (int i=0; i<4; i++) {
			bkgmat[i] = new float[1];
			bkgmat[i][0] = 0;
		}
		
		float *bkg = new float[4];
		for (int i=0; i<numSequence; i++) {
			if (sequences[i]->RealLength() < 20) {
				continue;
			}							
			sequences[i]->ComputeBaseFrequencies(bkg);
			for (int j=0; j<4; j++) {
				bkgmat[j][0] += bkg[j];
			}
		}
		
		bkgwm = new WtMx(bkgmat,1,"Background");  // create a length 1 wm for background 
		
		delete [] bkg;
		for (int i=0; i<4; i++) 
			delete [] bkgmat[i];
		delete [] bkgmat;
	}
	else {
		// now train a Markov chain.
		int morder = Markov_Order;
		int powmorder = (int)(pow(4,morder));
		
		float ***bkgmat = new float **[powmorder];
		for (int i=0; i<powmorder; i++) {
			bkgmat[i] = new float *[4];
			for (int j=0; j<4; j++) {
				bkgmat[i][j] = new float[1];
				bkgmat[i][j][0] = 0;
			}
		}
		
		float **bkg = new float *[powmorder];
		for (int i=0; i<powmorder; i++) bkg[i] = new float[4];
		for (int s=0; s<numSequence; s++) {
			if (sequences[s]->RealLength() < 20) {
				continue;
			}							
			sequences[s]->ComputeBaseFrequenciesWithHistory(bkg,morder);
			for (int i=0; i<powmorder; i++) {
				for (int j=0; j<4; j++) {
					bkgmat[i][j][0] += bkg[i][j];
				}
			}
		}
		
		
		float **basicbkgmat = new float *[4];
		for (int i=0; i<4; i++) {
			basicbkgmat[i] = new float[1];
			basicbkgmat[i][0] = 0; 
		}
		
		float *basicbkg = new float[4];
		for (int s=0; s<numSequence; s++) {
			if (sequences[s]->RealLength() < 20) {
				continue;
			}							
			sequences[s]->ComputeBaseFrequencies(basicbkg);
			for (int i=0; i<4; i++) {
				basicbkgmat[i][0] += basicbkg[i];
			}
		}
		
		bkgwm = new WtMx(bkgmat,basicbkgmat,1,"Background",morder);
		
		for (int i=0; i<powmorder; i++) {
			for (int j=0; j<4; j++) {
				delete [] bkgmat[i][j];
			}
			delete [] bkgmat[i];
			delete [] bkg[i];
		}
		delete [] bkgmat;
		delete [] bkg;
		for (int i=0; i<4; i++) {
			delete [] basicbkgmat[i];
		}
		delete [] basicbkg;
		delete [] basicbkgmat;
	}
	
	return bkgwm;
}

bool SequenceWtMxToolbox::OccursAt(Sequence *seq, int start, WtMx *wm, DTYPE *llr)
{
	// check the global cache kept in the sequence object
#ifdef _OPTIMIZE_PROTECTED_ACCESS
	struct probabilitycache *pc = (struct probabilitycache *)(seq->_udata);
#else
	struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
#endif
	
	if (pc != NULL) {
		int index = -1;
#ifndef _OPTIMIZE_WMINDEX
		for (int i=0; i<pc->_numWM; i++) {
			if (pc->_wms[i]==wm) {
				index = i;
				break;
			}
		}
#else
#ifdef _OPTIMIZE_PROTECTED_ACCESS
		index = wm->_udata;
#else
		index = wm->GetUserData();
#endif
#endif
		// if found, fetch the prob from the cache
		if (index >= 0) {
		  if (llr) *llr = pc->_llr[index][start];
		  return pc->_occursat[index][start];
		}
	}
	return false;  // if no cache, assume that the  motif may occur here
}

DTYPE SequenceWtMxToolbox::SumLRatSites(Sequence *seq, WtMx *wm)
{
  // check the global cache kept in the sequence object
#ifdef _OPTIMIZE_PROTECTED_ACCESS
  struct probabilitycache *pc = (struct probabilitycache *)(seq->_udata);
#else
  struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
#endif
  
  if (pc != NULL) {
    int index = -1;
#ifndef _OPTIMIZE_WMINDEX
    for (int i=0; i<pc->_numWM; i++) {
      if (pc->_wms[i]==wm) {
	index = i;
	break;
      }
    }
#else
#ifdef _OPTIMIZE_PROTECTED_ACCESS
    index = wm->_udata;
#else
    index = wm->GetUserData();
#endif
#endif
    // if found, fetch the prob from the cache
    if (index >= 0) {      
      return pc->_sumlratsites[index];
    }
    fprintf(stderr,"Error: SumLRatSites called without caching\n");
    exit(1);
  }
}

DTYPE SequenceWtMxToolbox::SumSiteStrength(Sequence *seq, WtMx *wm)
{
  // check the global cache kept in the sequence object
#ifdef _OPTIMIZE_PROTECTED_ACCESS
  struct probabilitycache *pc = (struct probabilitycache *)(seq->_udata);
#else
  struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
#endif
  
  if (pc != NULL) {
    int index = -1;
#ifndef _OPTIMIZE_WMINDEX
    for (int i=0; i<pc->_numWM; i++) {
      if (pc->_wms[i]==wm) {
	index = i;
	break;
      }
    }
#else
#ifdef _OPTIMIZE_PROTECTED_ACCESS
    index = wm->_udata;
#else
    index = wm->GetUserData();
#endif
#endif
    // if found, fetch the prob from the cache
    if (index >= 0) {      
      return pc->_sumsitestrength[index];
    }
    fprintf(stderr,"Error: SumSiteStrength called without caching\n");
    exit(1);
  }
}

WtMx **SequenceWtMxToolbox::GetWtMxs(Sequence *seq)
{
#ifdef _OPTIMIZE_PROTECTED_ACCESS
	struct probabilitycache *pc = (struct probabilitycache *)(seq->_udata);
#else
	struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
#endif
	if (pc == NULL) return NULL;
	return pc->_wms;
}

////////////////////////////////////////////////////////////////////////////////
// The most important method in this class : compute the subsequence probability
////////////////////////////////////////////////////////////////////////////////

DTYPE  SequenceWtMxToolbox::ComputeSequenceProbability(Sequence *seq, int start, int stop, WtMx *wm, int orientations)
// Optimizations: Doesnt check if stop >= start
//                Doesnt check if (stop-start+1) >= wm->Length()
// RETURNS LOGARITHM OF PROBABILITY
// if orientations == 0, forward strand only, 
// if orientations == 1, backward strand only,
// if orientations == 2, both strands
// if found in cache, orientations not considered
// Assumptions: both_orientations ignored if markov_order > 0; only use forward orientation
{
	int wm_len = wm->Length();
	
	// check the global cache kept in the sequence object
#ifdef _OPTIMIZE_PROTECTED_ACCESS
	struct probabilitycache *pc = (struct probabilitycache *)(seq->_udata);
#else
	struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
#endif
	
	if (pc != NULL) {
		int index = -1;
#ifndef _OPTIMIZE_WMINDEX
		for (int i=0; i<pc->_numWM; i++) {
			if (pc->_wms[i]==wm) {
				index = i;
				break;
			}
		}
#else
#ifdef _OPTIMIZE_PROTECTED_ACCESS
		index = wm->_udata;
#else
		index = wm->GetUserData();
#endif
#endif
		// if found, fetch the prob from the cache
		if (index >= 0) {
			if (stop < pc->_length && stop-start+1==wm_len) {
				return pc->_prob[index][start];
			}
		}
	}  
	
	// if reached here, nothing found in cache
	int ss_len = stop-start+1;
	
	int history_length = wm->MarkovOrder();
	
	// first handle the simple case of no markov history
	if (history_length == 0) {
		if (orientations == 0) {
			DTYPE  prob = 1;
			for (int i=0; i<ss_len; i++) {
				char ch = seq->IndexOfCharAt(start+i);
				prob *= wm->Frequency(i,ch);
				
			}
		
			return log(prob);
		}
		
		if (orientations == 1) {
			DTYPE  prob_rc = 1;
			for (int i=0; i<ss_len; i++) {
				char indch = seq->IndexOfCharAt(start+i);
				if (indch >= 0 && indch <= 3) {
					prob_rc *= wm->Frequency(wm_len-1-i,3-indch);
				}
				else 
					prob_rc *= wm->Frequency(wm_len-1-i,indch);
				
			}
			return log(prob_rc);
		}

		if (orientations == 2) {
			DTYPE  prob = 1;
			for (int i=0; i<ss_len; i++) {
				char ch = seq->IndexOfCharAt(start+i);
				prob *= wm->Frequency(i,ch);
			}
			
			DTYPE  prob_rc = 1;
			for (int i=0; i<ss_len; i++) {
				char indch = seq->IndexOfCharAt(start+i);
				if (indch >= 0 && indch <= 3) {
					prob_rc *= wm->Frequency(wm_len-1-i,3-indch);
				}
				else 
					prob_rc *= wm->Frequency(wm_len-1-i,indch);				
			}

			return log((prob+prob_rc)/2);
		}
	}
	
	// else history required
	// first construct the initial history word
	// only allow unit-length matrix
	// only forward orientation considered
	
	if (ss_len > 1) {
		printf("Error: ComputeSequenceProbability called with history and non-unit length matrix\n");
		exit(1);
	}
	int history = -1;
	int last_ambiguous_seen_at = -1;
	for (int i=0; i<history_length; i++) {    
		int hpos = start-history_length+i;
		if (hpos < 0) {
			history = -1;
			last_ambiguous_seen_at = hpos;
			break;
		}
		if (seq->AmbiguousCharAt(hpos)) {
			history = -1; 
			last_ambiguous_seen_at = hpos;
			break;
		}
		char ch = seq->IndexOfCharAt(hpos);
		if (ch == -1) {
			printf("Error: ComputeSequenceProbability called for horder and multiple sequence\n");
			exit(1);
		}
		if (i==0) { // first iteration : initialize the history array if needed
			history = ch;
		}
		else {
			history = history*4+ch;;
		}
	}
	
	DTYPE  prob = 1;
	for (int i=0; i<ss_len; i++) {
		int start_plus_i = start+i;
		// retrieve the current character and multiply prob by its probability
		char ch = seq->IndexOfCharAt(start_plus_i);
		bool not_enough_history = (start_plus_i-last_ambiguous_seen_at <= history_length);
		if (not_enough_history) {
			prob *= wm->Frequency(i,ch);
		}
		else {
			prob *= wm->Frequency(i,ch,history);
		}
		
	}
	
	return log(prob); // both_orientations ignored for markov_order > 0
}

