#ifndef _independentfreeenergyfunction_h_
#define _independentfreeenergyfunction_h_

#include "SequenceWtMxToolbox.h"

class IndependentPairFreeEnergy {
  struct coords {
    int start;
    int stop;
  };

  // these are pointers to objects that are handed over to this object  
  // 1. sequences and windows 
  Sequence **_sequence;  // if this is to run on multiple sequences simultaneously; _window is meaningless then
  coords    *_window;    // 
  int        _numSeqs;
  int       *_length;

  // 2. weight matrices
  WtMxCollection *_wmc;
  WtMx           *_bkgwm; // may be NULL, in which case local background will be used
  int             _numWM; // 1 + number of wtmxs in _wmc
  int             _bkgIndex; 

  // these are the parameters that will be trained
  DTYPE  *_pi; // motif transition probability parameters 
  DTYPE  *_prev_pi; // previous values of pi
  bool    _flag_update_transition_motif;  // transition probabilities for motif states
  DTYPE  global_weight; // the single global motif weight
  bool   _flag_weight_constraint; // if set, do not allow motif pi below global_weight
  
  // these are the posteriors
  DTYPE *_Ai; // this is the sum over all sequences, of average count of motif i

  // these are local data structures used in computation
  DTYPE *_alpha;  // forward dynamic programming   _alpha[l]
  DTYPE *_beta;   // backward dynamic programming   _beta[l]
  DTYPE _fringe_correction;
  
  // used to initialize the parameters
  int     _initialbias;

  DTYPE   _free_energy;

  bool    _convergence_problems;

  // flag to set off curtailing of iterations
  bool    _optimize_iteration_progress;
  DTYPE   _improvement_threshold;
  
  // misc constants
  static const float SMALL_FLOAT = 1E-10;        // when is a number too small to divide by 
  static const double SMALL_DOUBLE = 1E-30;  
  static const float INF_FREE_ENERGY = 1000000;
  static const float ALMOST_ONE = 0.99;           // used to initialize parameters to an extreme point
  static const int   CHECK_ITERATION_THRESHOLD = 20;
  static const int   MAX_TRAINING_ITERATIONS = 100;
  static const float CHECK_FEN_THRESHOLD = 0.1;
  
  char ReverseChar(char ch);                     // utility function

  // this is where the computation happens
  void ForwardDP(int j); 
  void BackwardDP(int j);
  void Posteriors(int j);
  void Update();
  void Revert();
  bool ConvergenceProblems();

public:
  // constructors and destructors
  IndependentPairFreeEnergy(Sequence **s1, int numSeqs, WtMxCollection *wmc1);
  IndependentPairFreeEnergy(Sequence **s1, int numSeqs, WtMxCollection *wmc1, int start, int stop);
  void ConstructHelper(Sequence **s1, int numSeqs, WtMxCollection *wmc1);
  ~IndependentPairFreeEnergy();
  
  // main function
  DTYPE  Train(bool differential=false);
  DTYPE  EvaluateFreeEnergy(bool compute=true);
  void   SetImprovementThreshold(DTYPE threshold);
  void   SetPi(DTYPE pi);
  void   GetPi(DTYPE &pi);
  void   SetGlobalWeight(DTYPE mw);
  void   SetWeightConstraint();
  void   PrintSingleLine(int spcindex);
  // set up 
  void   InitializeParameters(WtMx *bkgwm, int initialbias = -1);
  void   RandomInitializeParameters();
  void   FlagUpdateMotifTransitionProbs(bool flag); // was earlier FlagUpdateTransitionProbs

  // retrieve
  DTYPE  Free_Energy();
  int    NumWM();

  // this constant needs to be visible outside
  static const float THRESHOLD = 1e-2;           // used to terminate training
};

#endif
