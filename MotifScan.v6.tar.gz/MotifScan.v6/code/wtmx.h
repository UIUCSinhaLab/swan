#ifndef _wtmx_h_ 
#define _wtmx_h_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "typedefs.h"

#define PSEUDO_COUNT 0.1

// The Weight matrix class

class WtMx {
	float ***_wtmx;
	int      _length;
	bool     _is_normalized;
	char     _name[1024];
	char     _header[1024];
	void     Normalize();
	
	static const float SMALL_FREQUENCY = 1e-10;
	static int globalid;
	
	bool     _is_special;
	char     _special_char;
	
	int      _Morder;     // Markov order: how many previous characters this sees
	int      _powMorder;  // pow(4,_Morder)
	float  **_basicwtmx;  // used when Morder > 0 and history word not known
	float   *_higherwtmx; // as above, except this is for k-mers
	
	float    _pseudo_count;
	float    _forward_bias;
	int      _udata;
	float    _rethresh;   // threshold on site REs 
	float    _repvalthresh;   // threshold on site REs 
	
public:
		WtMx(float **w, int len, char *nm, float psd = PSEUDO_COUNT);
	// w[i][j] : i is 0..3, j is 0..wlength
	WtMx(float ***w, float **bw, int len, char *nm, int Morder, float psd = PSEUDO_COUNT);
	// w[m][i][j] : m is 0..4^Markovorder, i is 0..3, j is 0..wlength
	WtMx(char ch);
	WtMx(WtMx *w);
	~WtMx();
	
	void     Print(FILE *fp = stdout);
	void     Name(char *str, int pad_to = 16);
	float    Frequency(int offset, int index);
	float    Frequency(int offset, int index, int history);
	float    Frequency(int offset, int index, char *history, int history_length);
	float    HigherOrderFrequency(int offset, int index);
	int      MarkovOrder();
	int      Length();
	void     UpdateFrequency(int offset, float *freq);
	char     GetRandomChar(int offset);
	char     GetRandomChar(int offset, int history);
	char     GetRandomChar(int offset, char *history, int history_length);
	void     SetUserData(int d);
	int      GetUserData();
	void     SetForwardBias(float bias);
	float    GetForwardBias();
	void     SetREThresh(float thresh);
	float    GetREThresh();
	void     SetREPvalThresh(float thresh);
	float    GetREPvalThresh();
	void    REPval2RE(float pvalthresh, float &rethresh, float &repval);
	bool     HasRepressorLabel();
	void     SetHeader(char *str);
	
#ifdef _OPTIMIZE_PROTECTED_ACCESS
	friend class SequenceWtMxToolbox;
#endif
	
};


// Collection of weight matrices

#include <vector>
using namespace std;

class WtMxCollection {
	vector<WtMx *>  _vec;
	vector<int>     _valid;
	int             _numValid;
	
public:
		WtMxCollection();
	WtMxCollection(char *flname);
	~WtMxCollection();
	
	int  Add(WtMx *w);           // add a new matrix to collection
	WtMx *Remove(int index);     // delete the (index+1)th valid matrix from collection
	WtMx *WM(int index);         // return the (index+1)th valid matrix
	int  Size();                 // number of valid matrices currently
	int  TotalSize();            // total number of matrices currently
	int  MaxLength();
	void Print();
};



#define MAX_MOTIF_LENGTH 32

#endif


