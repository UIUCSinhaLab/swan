#include "IndependentPairFreeEnergy.h"
#include "SequenceWtMxToolbox.h"
#include <math.h>
#ifdef _DEBUG
#include <sys/time.h>
#endif

static DTYPE NEGINF;

static DTYPE LOGsum (DTYPE x, DTYPE y)
{
	
  if (x <= NEGINF) {
    if (y <= NEGINF) return NEGINF;
    else return y;
  }
  else {
    if (y <= NEGINF) return x;
    else {
      if (y >= x) return y + log(1+exp(x-y));
      return x + log(1+exp(y-x));
    }
  }
}

void IndependentPairFreeEnergy::ConstructHelper(Sequence **s1, int numSeqs, WtMxCollection *wmc1)
{
  // copy over the input information
  _sequence = new Sequence *[numSeqs];
  _window = new struct coords[numSeqs];
  _numSeqs = numSeqs;
	
  _length = new int[numSeqs];
  for (int i=0; i<numSeqs; i++) {
    _sequence[i] = s1[i];
    _length[i] = s1[i]->Length();
    _window[i].start = 0;
    _window[i].stop = _length[i]-1;
  }
	

  _wmc = wmc1;
  _bkgwm = NULL;
	
  // initialize flags to update
  _flag_update_transition_motif = true;
  _flag_weight_constraint = false;
	
  _convergence_problems = false;
	
  NEGINF = log(0);
}

IndependentPairFreeEnergy::IndependentPairFreeEnergy(Sequence **s1, int numSeqs, WtMxCollection *wmc1)
{
  ConstructHelper(s1, numSeqs, wmc1);
}

IndependentPairFreeEnergy::IndependentPairFreeEnergy(Sequence **s1, int numSeqs, WtMxCollection *wmc1, int start, int stop)
{
  ConstructHelper(s1, numSeqs, wmc1);
  if (numSeqs != 1) { printf("Error: window specified, but multiple (or zero) sequences given\n"); exit(1); }
  _window[0].start = start;
  _window[0].stop = stop;
  _length[0] = stop-start+1;
}

void IndependentPairFreeEnergy::InitializeParameters(WtMx *bkgwm, int initial_bias)
  // initial_bias is to initialize the _pi parameters
  // bkgwm is to initialize background, could be NULL.
{
  _bkgwm = bkgwm; // this may be null, in which case we'll later use the cached version per sequence
  _numWM = _wmc->Size()+1;
  _bkgIndex = _numWM-1;
	
  // create space for the _pi parameters and initialize them
  _pi = new DTYPE[_numWM];  
  if (_numWM == 1) { // no motifs (except background) 
    _pi[0] = 1; 
  }
  else {
    for (int i=0; i<_numWM; i++) {
      if (initial_bias < 0) {
	_pi[i] = 1/DTYPE(_numWM);   // initialize to the uniform distribution
      }
      else {
				
	if (i == initial_bias) _pi[i] = ALMOST_ONE;
	else _pi[i] = (1-ALMOST_ONE)/(_numWM-1);
				
      }
    }
  }
  _prev_pi = new DTYPE[_numWM];
  for (int i=0; i<_numWM; i++) { _prev_pi[i] = _pi[i]; }

  // create space for posteriors
  _Ai = new DTYPE[_numWM];
  for (int i=0; i<_numWM; i++) _Ai[i] = NEGINF;
	
  // create space for the DP table (from 0 to L+1, the two extremes are base conditions)
  int maxlen = 0;
  for (int j=0; j<_numSeqs; j++) {
    if (_length[j] > maxlen) maxlen = _length[j];
  }
  _alpha = new DTYPE[maxlen+2];
  _beta  = new DTYPE[maxlen+2];
	
  // clear flags
  _optimize_iteration_progress = false;
	
  return;
}

IndependentPairFreeEnergy::~IndependentPairFreeEnergy()
{
	
  delete [] _sequence;
  delete [] _length;
  delete [] _window;
	
  delete [] _alpha;
  delete [] _beta;
	
  delete [] _Ai;
	
  delete [] _pi;
  delete [] _prev_pi;
}


DTYPE IndependentPairFreeEnergy::Train(bool differential)
  // Free Energy refers to - log likelihood
  // So we want to minimize this
{
  DTYPE  previousFreeEnergy = INF_FREE_ENERGY;
  _free_energy = EvaluateFreeEnergy();
  DTYPE null_free_energy = _free_energy;	
	
#ifdef _LOGGING
  fprintf(stderr,">Begin training\n");
  fprintf(stderr,"Initial values:\t%.6f\t%.6f\n",_free_energy,_pi[0]);
#endif
	
  int count = 0;
  int count_below_improvement_threshold = 0;
  do {
    count++;
    previousFreeEnergy = _free_energy;
    Update();
    _free_energy = EvaluateFreeEnergy(); // this will do forward, backward, and posteriors
		
    // check improvement: new free energy should be less than before
    DTYPE improvement = previousFreeEnergy - _free_energy;
    if (improvement > 0 && improvement < _improvement_threshold) count_below_improvement_threshold++;
    else count_below_improvement_threshold = 0;
		
		
#ifdef _LOGGING
    fprintf(stderr,"Train iteration: %d\t-logProb: %.6f\tImprovement: %.6f\tmotifWeight: %.6f\n",count,_free_energy,improvement,_pi[0]);
#endif
		
    // stop if 2 continuous iterations without improvement
    if (_optimize_iteration_progress && count_below_improvement_threshold >= 2) break;
		
    if (count > MAX_TRAINING_ITERATIONS) break;    
    if (previousFreeEnergy - _free_energy < 0) {
      {
	fprintf(stderr,"problems converging free energy: %f %f \n", previousFreeEnergy, _free_energy);
	_convergence_problems = true;
	Revert();
	_free_energy = EvaluateFreeEnergy(); 
	break;
      }
    }
  } while (previousFreeEnergy - _free_energy > THRESHOLD);
	
#ifdef _LOGGING
  fprintf(stderr,">End training\n");
#endif
	
  if (differential) return (null_free_energy - _free_energy);
  return _free_energy;
}

DTYPE IndependentPairFreeEnergy::EvaluateFreeEnergy(bool compute)
{  
  DTYPE logP = 0; // log 1
  // Need to clear previous information:                                      
  // Did not need this for _alpha and _beta (ForwardDP and BackwardDP) since  
  // _alpha and _beta only reflect the last sequence (j) seen                 
  // However, _Ai is a sum over all sequences, and is therefore not initialized
  // by Posteriors(j)                                                         
  for (int i=0; i<_numWM; i++) _Ai[i] = NEGINF; // log 0                      
  for (int j=0; j<_numSeqs; j++) {
    // if the promoter is very small or highly masked, then ignore
    if (_sequence[j]->RealLength() < 20) {
      continue;
    }				
    ForwardDP(j);
    // need to multiply the alpha with termination probability 
    DTYPE term = LOGsum(_alpha[_length[j]],_fringe_correction);
    logP += term;
    BackwardDP(j);
    Posteriors(j);
#ifdef _DEBUG
    fprintf(stderr,"Training on sequence %d: fen = %g\tterm = %g\tAi[0] = %g\tAi[1] = %g\n",j,logP,term,_Ai[0],_Ai[1]);
#endif
  }
	
  return -logP;
}

void IndependentPairFreeEnergy::ForwardDP(int j)
{
  // cache all the WtMx pointers in an array, for repeated use
  WtMx **wm1 = new WtMx *[_numWM];
  int *wm_len = new int[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i == _bkgIndex) {
      if (_bkgwm) wm1[i] = _bkgwm;
      else wm1[i] = (SequenceWtMxToolbox::GetWtMxs(_sequence[j]))[_bkgIndex];
    }
    else {
      wm1[i] = _wmc->WM(i);
    }
    wm_len[i] = wm1[i]->Length();
  }
	
  // Clear up previous information
  for (int l=0; l<=_length[j]+1; l++) {
    _alpha[l] = NEGINF;
  }    
	
  // some optimization stuff
  DTYPE *pi = new DTYPE[_numWM];
  for (int i=0; i<_numWM; i++) {
    pi[i] = log(_pi[i]);
  }	
	
  bool  **occursat;
  DTYPE **CSPCache;
  // occursat[i][l] contains OccurstAt for start position l in current window for wm i 
  // CSPCache[i][l] contains CSP for start position l in current window for wm i
  // for both of these, the first position of the window is indexed by l=0
  occursat = new bool  *[_numWM];
  CSPCache = new DTYPE *[_numWM];
  for (int i=0; i<_numWM; i++) {
    occursat[i] = new bool [_length[j]+1];
    CSPCache[i] = new DTYPE[_length[j]+1];
    int wm_len_i = wm_len[i];
    WtMx **wm = wm1;
    for (int l=0, ln=l+_window[j].start; l<=(_length[j]-wm_len_i); l++,ln++) {
      if (i != _bkgIndex) occursat[i][l] = _sequence[j]->OccursAt(ln,wm[i]);
      else occursat[i][l] = true;
#ifdef _OPTIMIZE_OCCURSAT
      if (i != _bkgIndex && !occursat[i][l]) {
	CSPCache[i][l] = NEGINF; // log 0
	continue;
      }
#endif
      CSPCache[i][l] = SequenceWtMxToolbox::ComputeSequenceProbability(_sequence[j],ln,ln+wm_len_i-1,wm[i]);
    }
  }
	
#ifdef _DEBUG
  timeval tim;
  gettimeofday(&tim, NULL);
#endif
	
  // do the Dynamic Programming
	
  // Base condition
  _alpha[0] = 0; // log 1 // NEGINF; // log 0
	
  // Recurrences :-
	
  for (int l1=1; l1<=_length[j]; l1++) {
    int ln1 = l1+_window[j].start-1;

    // if ambiguous character (N or X), copy previous entry(s)
    if (_sequence[j]->AmbiguousCharAt(ln1)) {
      _alpha[l1] = _alpha[l1-1];
      continue;
    }
		
    // do the DP recursion       
    DTYPE sum = NEGINF;
    for (int i=0; i<_numWM; i++) {	     	
      int wm_len_i = wm_len[i];	
      if (l1-wm_len_i < 0) continue; // must plant, ending at l1
			
#ifdef _OPTIMIZE_OCCURSAT
      if (i != _bkgIndex && !occursat[i][l1-wm_len_i]) continue; // note: l1-wm_len_i+1 -1 (occursat uses base 0)
#endif
			
      DTYPE term = 0; // log 1
				
      term += pi[i]; // log _p_i
      term += CSPCache[i][l1-wm_len_i]; // note: l1-wm_len_i+1 -1 (CSPCache uses base 0)
			
      if (l1-wm_len_i > 0) 
	term += _alpha[l1-wm_len_i];
			
      sum = LOGsum(sum,term);
    }
    _alpha[l1] = sum;
  }

  _fringe_correction = NEGINF;
	
  // Clean up
  for (int i=0; i<_numWM; i++) {
    delete [] CSPCache[i];
    delete [] occursat[i];
  }
  delete [] CSPCache;
  delete [] occursat;
  delete [] pi;
  delete [] wm1;
  delete [] wm_len;
}

void IndependentPairFreeEnergy::BackwardDP(int j)
{
  // cache all the WtMx pointers in an array, for repeated use
  WtMx **wm1 = new WtMx *[_numWM];
  int *wm_len = new int[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i == _bkgIndex) {
      if (_bkgwm) wm1[i] = _bkgwm;
      else wm1[i] = (SequenceWtMxToolbox::GetWtMxs(_sequence[j]))[_bkgIndex];
    }
    else {
      wm1[i] = _wmc->WM(i);
    }
    wm_len[i] = wm1[i]->Length();
  }
	
  // Clear up previous information
  for (int l=0; l<=_length[j]+1; l++) {
    _beta[l] = NEGINF;
  }    
	
  // some optimization stuff
  DTYPE *pi = new DTYPE[_numWM];
  for (int i=0; i<_numWM; i++) {
    pi[i] = log(_pi[i]);
  }	
	
  bool  **occursat;
  DTYPE **CSPCache;
  // occursat[i][l] contains OccurstAt for start position l in current window for wm i in species j
  // CSPCache[i][l] contains CSP for start position l in current window for wm i in species j
  // for both of these, the first position of the window is indexed by l=0
  occursat = new bool  *[_numWM];
  CSPCache = new DTYPE *[_numWM];
  for (int i=0; i<_numWM; i++) {
    occursat[i] = new bool [_length[j]+1];
    CSPCache[i] = new DTYPE[_length[j]+1];
    int wm_len_i = wm_len[i];
    WtMx **wm = wm1;
    for (int l=0, ln=l+_window[j].start; l<=(_length[j]-wm_len_i); l++,ln++) {
      if (i != _bkgIndex) occursat[i][l] = _sequence[j]->OccursAt(ln,wm[i]);
      else occursat[i][l] = true;
#ifdef _OPTIMIZE_OCCURSAT
      if (i != _bkgIndex && !occursat[i][l]) {
	CSPCache[i][l] = NEGINF; // log 0
	continue;
      }
#endif
      CSPCache[i][l] = SequenceWtMxToolbox::ComputeSequenceProbability(_sequence[j],ln,ln+wm_len_i-1,wm[i]);
    }
  }
	
#ifdef _DEBUG
  timeval tim;
  gettimeofday(&tim, NULL);
#endif
	
  // do the Dynamic Programming
	
  // Base condition
  _beta[_length[j]+1] = 0; // log 1 // NEGINF; // log 1 = 0
	
  // Recurrences :-
	
  for (int l1=_length[j]; l1 > 0; l1--) {
    int ln1 = l1+_window[j].start-1;

    // if ambiguous character (N or X), copy previous entry(s)
    if (_sequence[j]->AmbiguousCharAt(ln1)) {
      _beta[l1] = _beta[l1+1];
      continue;
    }
		
    // do the DP recursion 
    DTYPE sum = NEGINF;
    for (int i=0; i<_numWM; i++) {	     	
      int wm_len_i = wm_len[i];	
      if (l1+wm_len_i-1 > _length[j]) continue; // must plant, starting at l1 and ending before end-of-sequence
			
#ifdef _OPTIMIZE_OCCURSAT
      if (i != _bkgIndex && !occursat[i][l1-1]) continue; // l1 (-1) (occursat uses base 0)
#endif
			
      DTYPE term = 0; // log 1
      term += pi[i]; // log _p_i
      term += CSPCache[i][l1-1]; // note: CSPCache uses base 0
      if (l1+wm_len_i <= _length[j])
	term += _beta[l1+wm_len_i];
			
      sum = LOGsum(sum,term);
    }
    _beta[l1] = sum;
  }
    
  // Clean up
  for (int i=0; i<_numWM; i++) {
    delete [] CSPCache[i];
    delete [] occursat[i];
  }
  delete [] CSPCache;
  delete [] occursat;
  delete [] pi;
  delete [] wm1;
  delete [] wm_len;
}

void IndependentPairFreeEnergy::Posteriors(int j) 
  // j stands for sequence index
  // uses _sequence[j] and _length[j], stores into _Ai[i] for all wmindex i.
{
  // cache all the WtMx pointers in an array, for repeated use
  WtMx **wm1 = new WtMx *[_numWM];
  int *wm_len = new int[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i == _bkgIndex) {
      if (_bkgwm) wm1[i] = _bkgwm;
      else wm1[i] = (SequenceWtMxToolbox::GetWtMxs(_sequence[j]))[_bkgIndex];
    }
    else {
      wm1[i] = _wmc->WM(i);
    }
    wm_len[i] = wm1[i]->Length();
  }
	
  // some optimization stuff
  DTYPE *pi = new DTYPE[_numWM];
  for (int i=0; i<_numWM; i++) {
    pi[i] = log(_pi[i]);
  }	
	
  bool  **occursat;
  DTYPE **CSPCache;
  // occursat[i][l] contains OccurstAt for start position l in current window for wm i
  // CSPCache[i][l] contains CSP for start position l in current window for wm i
  // for both of these, the first position of the window is indexed by l=0
  occursat = new bool  *[_numWM];
  CSPCache = new DTYPE *[_numWM];
  for (int i=0; i<_numWM; i++) {
    occursat[i] = new bool [_length[j]+1];
    CSPCache[i] = new DTYPE[_length[j]+1];
    int wm_len_i = wm_len[i];
    WtMx **wm = wm1;
    for (int l=0, ln=l+_window[j].start; l<=(_length[j]-wm_len_i); l++,ln++) {
      if (i != _bkgIndex) occursat[i][l] = _sequence[j]->OccursAt(ln,wm[i]);
      else occursat[i][l] = true;
#ifdef _OPTIMIZE_OCCURSAT
      if (i != _bkgIndex && !occursat[i][l]) {
	CSPCache[i][l] = NEGINF; // log 0
	continue;
      }
#endif
      CSPCache[i][l] = SequenceWtMxToolbox::ComputeSequenceProbability(_sequence[j],ln,ln+wm_len_i-1,wm[i]);
    }
  }
	
#ifdef _DEBUG
  timeval tim;
  gettimeofday(&tim, NULL);
#endif
	
  DTYPE *Ai = new DTYPE[_numWM];
  for (int i=0; i<_numWM; i++) {
    int wm_len_i = wm_len[i];
    Ai[i] = NEGINF; // log 0
		
    // need to sum _Aijl for motif i, sequence j, and every position l in sequence j		
    // for l=1, we dont have alpha term in _Aijl
		
    DTYPE term;
#ifdef _OPTIMIZE_OCCURSAT
    if (i != _bkgIndex && !occursat[i][0]) { // note: 1 -1 (occursat uses base 0)
    }
    else {
#endif
      term = 0; // log 1
			
      // assume that sequence is longer than wm_len_i
      term += _beta[wm_len_i+1]; // log beta(1,l+1)
			
      term += pi[i]; // log _p_i
      term += CSPCache[i][0]; // note: 1 -1 (CSPCache uses base 0)
			
      Ai[i] = LOGsum(Ai[i], term);
			
#ifdef _OPTIMIZE_OCCURSAT
    }
#endif
		
    // sum over all l = 2 .. length-wm_len_i
		
    for (int l1=2; l1<=_length[j]-wm_len_i; l1++) {
#ifdef _OPTIMIZE_OCCURSAT
      if (i != _bkgIndex && !occursat[i][l1-1]) { // note: occursat uses base 0
	continue; 
      }
#endif	
      term = 0; // log 1
      term += _alpha[l1-1];
      term += pi[i];
      term += CSPCache[i][l1-1]; // (CSPCache uses base 0)
      term += _beta[l1+wm_len_i];

      Ai[i] = LOGsum(Ai[i], term);
    }
		
		
#ifdef _OPTIMIZE_OCCURSAT
    if (i != _bkgIndex && !occursat[i][_length[j]-wm_len_i]) { // (occursat uses base 0)
    }
    else {
#endif
      term = 0; // log 1
      term += _alpha[_length[j]-wm_len_i]; 
      term += pi[i]; // log _p_i
      term += CSPCache[i][_length[j]-wm_len_i]; // (CSPCache uses base 0)
			
      Ai[i] = LOGsum(Ai[i], term);	
#ifdef _OPTIMIZE_OCCURSAT
    }
#endif
		
    Ai[i] -=  LOGsum(_alpha[_length[j]],_fringe_correction);
    _Ai[i] = LOGsum(_Ai[i],Ai[i]);
		
#ifdef _DEBUG
    // fprintf(stderr,"Posteriors: _Ai[%d] = %g\n",i,_Ai[i]);
#endif
  }
  delete [] Ai;

  // Clean up
  for (int i=0; i<_numWM; i++) {
    delete [] CSPCache[i];
    delete [] occursat[i];
  }
  delete [] CSPCache;
  delete [] occursat;
	
  delete [] pi;
  delete [] wm1;
  delete [] wm_len;
}

void IndependentPairFreeEnergy::Revert()
{
  for (int i=0; i<_numWM; i++) _pi[i] = _prev_pi[i]; 
}
   
void IndependentPairFreeEnergy::Update()
{
  for (int i=0; i<_numWM; i++)  _prev_pi[i] = _pi[i];

  // now use these in the updates
  if (_flag_update_transition_motif) {
    DTYPE sum = NEGINF; // log 0
    for (int i=0; i<_numWM; i++) sum = LOGsum(sum, _Ai[i]);
    for (int i=0; i<_numWM; i++) {
      _pi[i] = exp(_Ai[i]-sum);
    }
    if (_flag_weight_constraint) {
      if (_pi[0] < global_weight) {
	_pi[0] = global_weight;
	_pi[1] = 1-global_weight;
      }
    }
		
#ifdef _DEBUG
    fprintf(stderr,"Updated parameters:");
    for (int i=0; i<_numWM; i++) fprintf(stderr,"%g ",_pi[i]);
    fprintf(stderr,"\n");
#endif
  }
}

void IndependentPairFreeEnergy::FlagUpdateMotifTransitionProbs(bool flag)
{
  _flag_update_transition_motif = flag;
}

char IndependentPairFreeEnergy::ReverseChar(char ch)
{
  switch(ch) {
  case 'A': return 'T';
  case 'C': return 'G';
  case 'G': return 'C';
  case 'T': return 'A';
  case 'R': return 'Y';
  case 'Y': return 'R';
  case 'S': return 'S';
  case 'W': return 'W';
  case 'N': return 'N';
  }
  return 'N';
}

DTYPE IndependentPairFreeEnergy::Free_Energy()
{
  return _free_energy;
}

int IndependentPairFreeEnergy::NumWM()
{
  return _numWM;
}

void IndependentPairFreeEnergy::PrintSingleLine(int spcindex)
{
	
  printf("%d\t%.3f\t",spcindex,_free_energy);
  for (int i=0; i<_numWM; i++) printf("%.4f\t",_pi[i]);
  if (_convergence_problems) printf("\tCONVERGENCE PROBLEMS");
  printf("\n");
}

void IndependentPairFreeEnergy::SetImprovementThreshold(DTYPE threshold)
{
  _improvement_threshold = threshold;
  _optimize_iteration_progress = true;
}

void IndependentPairFreeEnergy::RandomInitializeParameters()
{
  float sum = 0;
  for (int i=0; i<(_numWM-1); i++) {
    // a random number between 0 and x/(_numWM-1)
    float r = (float(rand())/RAND_MAX)*0.5/(_numWM-1);
    _pi[i] = r;
    sum += r;
  }
  _pi[_numWM-1] = 1-sum;
	
  float(rand())/RAND_MAX;
}

bool IndependentPairFreeEnergy::ConvergenceProblems()
{
  return _convergence_problems;
}

void IndependentPairFreeEnergy::SetPi(DTYPE pi)
{
  _pi[0] = pi;
  _pi[1] = 1-pi;
}

void IndependentPairFreeEnergy::GetPi(DTYPE &pi)
{
  pi = _pi[0];
}

void IndependentPairFreeEnergy::SetGlobalWeight(DTYPE mw)
{
  global_weight = mw;
}

void IndependentPairFreeEnergy::SetWeightConstraint()
{
  _flag_weight_constraint = true;
}
