#include <iostream>

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <map>

#include "typedefs.h"
#include "util.h"
#include "sequence.h"
#include "SequenceWtMxToolbox.h"
#include "IndependentPairFreeEnergy.h"
#include "fastafile.h"

int main(int argc, char **argv)
{
	if (argc < 4) {
		printf("usage: %s <fastafile> <wtmxfile1> <motifweight> [-od <output_dir>] [-b <background file>] [-m <Markov order>] [-mt <site percentile>] [-wc]\n",argv[0]);
		exit(1);
	}
	
	srandom((unsigned int)time(NULL));
	srand48((unsigned int)time(NULL));
	
	char *fastafile = argv[1];
	FastaFile *file = new FastaFile();
	file->ReadFasta(fastafile);
	
	Sequence **seqs = file->_sequences;
	int numSeqs = file->Size();
	
	char *wmc1file = argv[2];
	WtMxCollection *wmc1 = new WtMxCollection(wmc1file);
	if (wmc1->Size() != 1) { 
		printf("Can only scan for one motif at a time: file %s should have only one PWM\n");
		exit(1);
	}	
	
	float motifweight = atof(argv[3]);
	
	// Read in the optional arguments
	int argbase = 4;
	struct Options *opt = ReadOptionalArguments(argbase, argc, argv);
	
	// create background, if required to be global
	WtMx *bkgwm = NULL;
	Sequence **bkg_seq = new Sequence *[1];
	if (opt->bkg_file != NULL) {
		bkg_seq[0] = new Sequence(opt->bkg_file);
		bkgwm = SequenceWtMxToolbox::TrainBackground(bkg_seq,1,opt->markov_order);
		delete bkg_seq[0];
	}
	delete [] bkg_seq;
	
	// is there a (re-pvalue) threshold applied on motif occurrences ?
	if (opt->motif_repval_threshold >= 0) { 
		for (int i=0; i<wmc1->Size(); i++) {
			WtMx *wm = wmc1->WM(i);
			float rethresh; float pval;
			wm->REPval2RE(opt->motif_repval_threshold, rethresh, pval);
			wm->SetREThresh(rethresh);
			wm->SetREPvalThresh(pval);
		}
	}

	// cache probabilities for each sequence
	// store local bkg pwms (after creating them) if needed
	for (int i=0; i<numSeqs; i++) {
	  // fprintf(stderr,"Caching sequence %d\n",i);
	  // SequenceWtMxToolbox::CacheSubsequenceProbabilities(seqs[i],wmc1,bkgwm,opt->markov_order);
	}
	
	// Open file for output
	FILE *ener = OpenOutput (fastafile, opt->output_dir);

	char *name = new char[1024];
	// process 
	Sequence **seq = new Sequence *[1];
	for (int seqnum=0; seqnum < numSeqs; seqnum++) {
		seq[0] = seqs[seqnum];		
		seq[0]->Name(name);
		
		// if the promoter is very small or highly masked, then score = 0
		if (seq[0]->RealLength() < 20) {
			DTYPE llr = 0;
			fprintf(ener,"%d\t%s\t%g\t%f\n",seqnum,name,llr,motifweight);
			continue;
		}
		
		SequenceWtMxToolbox::CacheSubsequenceProbabilities(seq[0],wmc1,bkgwm,opt->markov_order);
		// create the parameters object
		IndependentPairFreeEnergy *ipfe = new IndependentPairFreeEnergy(seq,1,wmc1);
		ipfe->SetGlobalWeight(motifweight);
		if (opt->weight_constraint) {
			ipfe->SetWeightConstraint();
		}
		DTYPE bestllr = -1; DTYPE besttpi = -1;
		ipfe->InitializeParameters(bkgwm, wmc1->Size()); // bkgwm may be NULL, in which case cached bkgwm will be used
		ipfe->SetPi(motifweight);
		DTYPE null_fen = ipfe->EvaluateFreeEnergy();		
		// try training the free motif weight starting at four different vals: 1,2,3*motifweight, and 0.0025
		for (int f=1; f<=3; f++) {
			DTYPE p = f*motifweight;
			ipfe->SetPi(p);
			DTYPE llr = ipfe->Train(false);
			llr = null_fen - llr;
			DTYPE tpi;
			ipfe->GetPi(tpi);
			fprintf(stderr,"%d\t%s\t%g\t%g\t%g\n",seqnum,name,llr,tpi,p);
			if (llr > bestllr) { bestllr = llr; besttpi = tpi; }
		}
		DTYPE p = 0.0025;
		if (p > 3*motifweight) {
		  ipfe->SetPi(p);
		  DTYPE llr = ipfe->Train(false);
		  llr = null_fen - llr;
		  DTYPE tpi;
		  ipfe->GetPi(tpi);
		  fprintf(stderr,"%d\t%s\t%g\t%g\t%g\n",seqnum,name,llr,tpi,p);
		  if (llr > bestllr) { bestllr = llr; besttpi = tpi; }
		}

		fprintf(ener,"%d\t%s\t%g\t%g\n",seqnum,name,bestllr,besttpi);
		
		// clean up
		fprintf(stderr,"Done processing seq number %d\n",seqnum);
		delete ipfe;
		SequenceWtMxToolbox::DeleteCacheSubsequenceProbabilities(seq[0]);		
	}
	delete [] name;
	
	fclose(ener);
}

