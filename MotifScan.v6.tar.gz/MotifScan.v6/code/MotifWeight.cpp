#include <iostream>

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <map>

#include "typedefs.h"
#include "util.h"
#include "sequence.h"
#include "SequenceWtMxToolbox.h"
#include "IndependentPairFreeEnergy.h"
#include "fastafile.h"

int main(int argc, char **argv)
{
	if (argc < 3) {
		printf("usage: %s <fastafile> <wtmxfile1> [-b <background file>] [-m <Markov order>]  [-mt <site percentile>]\n",argv[0]);
		exit(1);
	}
	
	srandom((unsigned int)time(NULL));
	srand48((unsigned int)time(NULL));
	
	char *fastafile = argv[1];
	FastaFile *file = new FastaFile();
	file->ReadFasta(fastafile);
	
	Sequence **seqs = file->_sequences;
	int numSeqs = file->Size();
	
	char *wmc1file = argv[2];
	WtMxCollection *wmc1 = new WtMxCollection(wmc1file);
	if (wmc1->Size() != 1) { 
		printf("Can only scan for one motif at a time: file %s should have only one PWM\n");
		exit(1);
	}	
	
	// Read in the optional arguments
	int argbase = 3;
	struct Options *opt = ReadOptionalArguments(argbase, argc, argv);
	
	// create background, if required to be global
	WtMx *bkgwm = NULL;
	Sequence **bkg_seq = new Sequence *[1];
	if (opt->bkg_file != NULL) {
		bkg_seq[0] = new Sequence(opt->bkg_file);
		bkgwm = SequenceWtMxToolbox::TrainBackground(bkg_seq,1,opt->markov_order);
		delete bkg_seq[0];
	}
	delete [] bkg_seq;
	
	// is there a (re-pvalue) threshold applied on motif occurrences ?
	if (opt->motif_repval_threshold >= 0) { 
		for (int i=0; i<wmc1->Size(); i++) {
			WtMx *wm = wmc1->WM(i);
			float rethresh; float pval;
			wm->REPval2RE(opt->motif_repval_threshold, rethresh, pval);
			wm->SetREThresh(rethresh);
			wm->SetREPvalThresh(pval);
		}
	}

	// cache probabilities for each sequence
	// store local bkg pwms (after creating them) if needed
	for (int i=0; i<numSeqs; i++) {
		SequenceWtMxToolbox::CacheSubsequenceProbabilities(seqs[i],wmc1,bkgwm,opt->markov_order);
	}
	
	// process 
	IndependentPairFreeEnergy *ipfe = new IndependentPairFreeEnergy(seqs,numSeqs,wmc1);
	ipfe->InitializeParameters(bkgwm, wmc1->Size()); // bkgwm may be NULL, in which case cached bkgwm will be used
    
	// train the parameters
	DTYPE pi = 0.1; 
	ipfe->SetPi(pi);
	if (ipfe->Train() < 0) {
		printf("fen = ?\tpi = %g\tCONVPROB\n", pi);
		return 0;
	}

	DTYPE fen = ipfe->Free_Energy();
	DTYPE tpi;
	ipfe->GetPi(tpi);
	printf("fen = %g\tpi = %g\tseedpi = %g\n",fen, tpi, pi);
	
	// clean up
	delete ipfe;
}

