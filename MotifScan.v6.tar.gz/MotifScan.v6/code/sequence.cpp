#include "sequence.h"
#include <math.h>
#include "SequenceWtMxToolbox.h"

Sequence::Sequence(char *flname)
{
	FILE *fp = fopen(flname,"r");
	if (fp == NULL) {
		printf("Error reading file %s\n",flname);
		exit(1);
	}
	_seq = ReadFasta(fp);
	fclose(fp);
	
	_length = strlen(_seq);
	_reallength = 0;
	_indexseq = new char[_length];
	for (int i=0; i<_length; i++) {
		switch(_seq[i]) {
			case 'a':
			case 'A': _indexseq[i] = 0; break;
			case 'c':
			case 'C': _indexseq[i] = 1; break;
			case 'g': 
			case 'G': _indexseq[i] = 2; break;
			case 't':
			case 'T': _indexseq[i] = 3; break;
			default:  _indexseq[i] = 4;
		}
		if (_indexseq[i] < 4) _reallength++;
	}
	
	sprintf(_name,"No Name");
	_udata = NULL;
}

Sequence::Sequence(char *seq, int length, char *name)
{
	_seq = new char[length+1];
	strcpy(_seq,seq);
	_length = length;
	_reallength = 0;
	_indexseq = new char[_length];
	for (int i=0; i<_length; i++) {
		switch(_seq[i]) {
			case 'a':
			case 'A': _indexseq[i] = 0; break;
			case 'c':
			case 'C': _indexseq[i] = 1; break;
			case 'g': 
			case 'G': _indexseq[i] = 2; break;
			case 't':
			case 'T': _indexseq[i] = 3; break;
			default:  _indexseq[i] = 4;
		} 
		if (_indexseq[i] < 4) _reallength++;
	}
	
	strcpy(_name,name);
	_udata = NULL;
}

Sequence::~Sequence()
{
	delete [] _seq;
	delete [] _indexseq;
}

char Sequence::CharAt(int index)
{
	return _seq[index];
}

char Sequence::IndexOfCharAt(int index)
{
	return _indexseq[index];
}

bool Sequence::AmbiguousCharAt(int index)
{
	return (IndexOfCharAt(index) > 3);
}

int Sequence::Length()
{
	return _length;
}

int Sequence::RealLength()
{
	return _reallength;
}

char *Sequence::ReadFasta(FILE *fp)
{
	char line[MAX_LINE_LENGTH];
	do {
		fgets(line,MAX_LINE_LENGTH-1,fp);
	} while (line[0] == '#');
	
	if (line[0] != '>') {
		printf("Error: In Fasta file, each sequence must be preceded by a header line beginning with a '>'\n");
		printf("%d",strlen(line));
		printf(line);
		exit(1);
	}
	char *sequence = new char[MAX_SEQ_LENGTH+1];
	sequence[0] = 0;
	int seq_pos = 0;
	while (fgets(line,MAX_LINE_LENGTH-1,fp)) {
		if (line[0]=='#') continue;
		if (strstr(line,">")) {
			strcpy(&(sequence[seq_pos]),"$");
			seq_pos ++;
			continue;   // if we want all sequences as one
		}
		
		// chomp
		int last_pos = strlen(line)-1;
		if (line[last_pos]=='\n' || line[last_pos]=='\r') line[last_pos] = 0;
		
		// concatenate
		strcpy(&(sequence[seq_pos]),line);
		seq_pos += strlen(line);
	}
	char *retval = new char[strlen(sequence)+1];
	strcpy(retval,sequence);
	delete [] sequence;
	
	return retval;
}

void Sequence::Print(int start, int stop)
{
	for (int i=start; i<=stop; i++) {
		printf("%c",_seq[i]);
	}
	printf("\n");
}

void Sequence::Name(char *name)
{
	strcpy(name,_name);
}

void Sequence::SetUserData(void *udata)
{
	_udata = udata;
}

void *Sequence::GetUserData()
{
	return _udata;
}

void  Sequence::ComputeBaseFrequencies(float *freq)
{
	int counts[4];
	int i;
	
	for (i=0; i<4; i++) counts[i] = 0;
	int total = 0;
	for (i=0; i<_length; i++) {
		char ch = IndexOfCharAt(i);
		if (ch >= 4) continue;
		counts[ch]++; 
		total++;
	}
	for (i=0; i<4; i++) freq[i] = float(counts[i]);
}

void Sequence::ComputeBaseFrequenciesWithHistory(float **freq, int history_length)
{
	int i;
	int powmorder = int(pow(4,history_length));
	float *basic_freq = new float[4];
	
	// initialize
	for (i=0; i<4; i++) basic_freq[i]=0;
	for (i=0; i<powmorder; i++) {
		for (int j=0; j<4; j++) {
			freq[i][j] = 0;
		}
	}
	
	// construct the initial history word
	int mask = powmorder/4;
	int history = 0;
	char ch; int pos = 0; 
	for (i=0; i<history_length; i++) {
		// find the next non-ambiguous char
		while (pos < _length-1 && (ch = IndexOfCharAt(pos)) >= 4) pos++;
		// if not found, cannot do anything
		if (pos >= _length-1) {
			printf("Error: end of sequence encountered before a history word could be read\n");
			exit(1);
		}
		history = history*4 + ch;
	}
	
	// initial history word constructed
	// now scan the sequence and count bases
	// pos++;
	while (pos < _length) {
		// find the next non-ambiguous char
		while (pos < _length && (ch = IndexOfCharAt(pos)) >= 4) pos++;
		// if reached end, we're done counting
		if (pos >= _length) break;
		// else update the appropriate counts
		freq[history][ch]++;
		basic_freq[ch]++;
		// and update the history word also
		if (history_length > 0) {
			history = history%mask;
			history = history*4 + ch;
		}
		pos++;
	}
	
	// cleanup
	delete [] basic_freq;
}

bool Sequence::OccursAt(int pos, WtMx *wm, DTYPE *llr)
{
  if (llr) return SequenceWtMxToolbox::OccursAt(this, pos, wm, llr);
  else return SequenceWtMxToolbox::OccursAt(this, pos, wm);
}

DTYPE Sequence::SumLRatSites(WtMx *wm)
{
	return SequenceWtMxToolbox::SumLRatSites(this, wm);
}

DTYPE Sequence::SumSiteStrength(WtMx *wm)
{
	return SequenceWtMxToolbox::SumSiteStrength(this, wm);
}

