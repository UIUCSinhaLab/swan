#include "SequenceWtMxToolbox.NaiveHelper.h"
#include <math.h>

float SequenceWtMxToolboxNaive::MaxLLR(WtMx *wm, WtMx *bkgwm)
{
  float max = 0;
  for (int i=0; i<wm->Length(); i++) {
    DTYPE max_col = log(0); // neg inf
    for (int j=0; j<4; j++) {
      DTYPE val = log(wm->Frequency(i,j)/bkgwm->Frequency(0,j));
      if (val > max_col) max_col = val;
    }
    max += max_col;
  }
  return max;
}

void SequenceWtMxToolboxNaive::CacheSubsequenceProbabilities(Sequence *seq, WtMxCollection *wmc, WtMx *bkgwm, int markov_order)
  // bkgwm may be null
  // computes "occursat" in a slightly different way
{
  struct probabilitycache *oldpc = (struct probabilitycache *)(seq->GetUserData());
  // when asked to cache probabilities for a sequence, destroy any old cache that may be present
  if (oldpc != NULL) delete oldpc;
  seq->SetUserData(NULL);
	
  if (bkgwm == NULL) { // then create background for this sequence
    Sequence **bkg_seq = new Sequence *[1];
    bkg_seq[0] = seq;
    bkgwm = TrainBackground(bkg_seq,1,markov_order);
    delete [] bkg_seq;
  }
	
  // create the array of WtMx* from the given WtMxCollection
  int numWM = wmc->Size();
  WtMx **wms = new WtMx *[(numWM+(bkgwm?1:0))];
  for (int i=0; i<numWM; i++) {
    WtMx *wm = wmc->WM(i);
    wms[i] = wm;
#ifdef _OPTIMIZE_WMINDEX
    wm->SetUserData(i);
#endif
  }
  if (bkgwm) {
    wms[numWM] = bkgwm;
#ifdef _OPTIMIZE_WMINDEX
    bkgwm->SetUserData(numWM);
#endif
    numWM++;
  }
	
  int length = seq->Length();
	
  // create the actual array of subsequence probabilities
  DTYPE NEGINF = log(0);
  DTYPE  **prob = new DTYPE  *[numWM];
  DTYPE  **llr = new DTYPE  *[numWM];
  bool  **occursat = new bool *[numWM];
  DTYPE  *bkgprob_bothorient[2];
  DTYPE  *sumlratsites = new DTYPE[numWM]; // this will store the sum of lr at sites
  DTYPE  *sumsitestrength = new DTYPE[numWM]; // this will store the sum of llr/llr_max at sites

  // this array will store bkgprobs for each orientation.
  for (int o=0; o<2; o++) bkgprob_bothorient[o] = new DTYPE [length]; 

  for (int j=numWM-1; j>=0; j--) {  // first compute prob[][] for numWM-1, which is bkg, so that we have it later
    int wm_len = wms[j]->Length();
    if (j!=numWM-1) {
      prob[j] = new DTYPE  [length]; 
      llr[j] = new DTYPE  [length]; 
    } 
    else { 
      prob[j] = NULL;
      llr[j] = NULL;
    }
    occursat[j] = new bool  [length];
    DTYPE sumlr = 0;
    DTYPE sumss = 0;

    // set the llr threshold
    DTYPE llrthresh = 0;
    DTYPE maxllr=-1;
    if (j!=numWM-1) {
      maxllr = SequenceWtMxToolboxNaive::MaxLLR(wms[j],bkgwm);
      llrthresh = thresholdFactor * maxllr;
    }
    SequenceWtMxToolboxNaive::llrthreshold = llrthresh;
    
    for (int l=0; l<length-wm_len+1; l++) {
      DTYPE f_prob = SequenceWtMxToolbox::ComputeSequenceProbability(seq, l, l+wm_len-1, wms[j], 0);
      DTYPE r_prob = SequenceWtMxToolbox::ComputeSequenceProbability(seq, l, l+wm_len-1, wms[j], 1);
      if (j==numWM-1) {
	bkgprob_bothorient[0][l] = f_prob;
	bkgprob_bothorient[1][l] = r_prob;
	continue;
      }
      // if here, then this is a pwm, not bkg; so compute LLR and compare to max

      if (f_prob > r_prob) prob[j][l] = f_prob; else prob[j][l] = r_prob;

      DTYPE bkgprob_f = 0, bkgprob_r = 0;
      for (int p=0; p<wm_len; p++) {
	bkgprob_f += bkgprob_bothorient[0][l+p];
	bkgprob_r += bkgprob_bothorient[1][l+p];
      }
      
      DTYPE LLR_f = f_prob-bkgprob_f;
      DTYPE LLR_r = r_prob-bkgprob_r;

      DTYPE LLR = LLR_r;
      if (LLR_f > LLR_r) LLR = LLR_f;
      
      llr[j][l] = LLR/maxllr;
      if (LLR > llrthresh) {
	occursat[j][l] = true; 
	sumlr += exp(LLR);
	sumss += LLR/maxllr;
      }
      else occursat[j][l] = false;
    }
    sumlratsites[j] = sumlr;
    sumsitestrength[j] = sumss;
  }
  for (int o=0; o<2; o++) delete [] bkgprob_bothorient[o];
	
  // create a cache object
  struct probabilitycache *pc = new struct probabilitycache;
  pc->_numWM = numWM;
  pc->_length = length;
  pc->_wms = wms;
  pc->_prob = prob;
  pc->_llr = llr;
  pc->_occursat = occursat;
  pc->_sumlratsites = sumlratsites;
  pc->_sumsitestrength = sumsitestrength;

  // store this cache in the Sequence object
  seq->SetUserData((void *)pc);
}
