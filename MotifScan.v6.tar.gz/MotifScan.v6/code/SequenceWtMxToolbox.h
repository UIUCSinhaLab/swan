#ifndef _sequencewtmxfunction_h_
#define _sequencewtmxfunction_h_

#include <vector>
using namespace std;

#include "sequence.h"
#include "wtmx.h"
#include "typedefs.h"

#define DEFAULT_ORIENTATIONS 2
#define DEFAULT_MOTIF_OCCURRENCE_THRESHOLD 0.1
#define DEFAULT_FEN_THRESHOLD 10
#define DEFAULT_MARKOV_ORDER 0
#define COMPARE_BKG_SCALED_BY 1

#define abs(x) (x>0?x:-x)

extern float neutral_mu;
extern float neutral_mu_b;

class SequenceWtMxToolbox {
 public:
  // All subclasses of this class will need to compute the subsequence probability :
  static DTYPE  ComputeSequenceProbability(Sequence *seq, int start, int stop, WtMx *wm, int orientations=DEFAULT_ORIENTATIONS);

  // Data structure for optimizing Pr(s|W_i) by using a "cache" (W_i could be background also)
  // An object of this type should be placed in each Sequence object, using _udata.
  struct probabilitycache {                   
    DTYPE  **_prob;                           // _prob[j][k] is for (j==wm)(k==position in seq)
    DTYPE  **_llr;
    bool   **_occursat;                       // _occursat[j[[k] is for (j==wm)(k==position in seq)
    DTYPE   *_sumlratsites;                   // used only by NaiveHelper
    DTYPE   *_sumsitestrength;                // used only by NaiveHelper
    WtMx **_wms;                              // (*_wms[i]) is W_i
    int _length;                              // required when destroying _prob
    int _numWM;                               // required when destroyinf _prob, _wms

    probabilitycache();                                         // regular constructor
    probabilitycache(const probabilitycache &pc);               // copy constructor
    probabilitycache& operator=(const probabilitycache &pc);    // assignment operator
    ~probabilitycache();                                        // destructor

    private:
    void Destroy();
    void Copy(const probabilitycache &pc);
  };
  static void CacheSubsequenceProbabilities(Sequence *seq, WtMxCollection *wmc, WtMx *bkgwm, int markov_order);
  static void DeleteCacheSubsequenceProbabilities(Sequence *seq);
  static bool OccursAt(Sequence *seq, int start, WtMx *wm, DTYPE *llr = NULL);
  static DTYPE SumLRatSites(Sequence *seq, WtMx *wm);  
  static DTYPE SumSiteStrength(Sequence *seq, WtMx *wm);
  static WtMx **GetWtMxs(Sequence *seq);

  // Utility Method for producing background weight matrix out of sequence objects
  static WtMx *TrainBackground(Sequence **sequences, int numSequence, int Markov_Order = 0);  

};

#endif
