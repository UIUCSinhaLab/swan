#include <iostream>

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <map>

#include "typedefs.h"
#include "util.h"
#include "sequence.h"
#include "SequenceWtMxToolbox.h"
#include "IndependentPairFreeEnergy.h"
#include "fastafile.h"

int main(int argc, char **argv)
{
  if (argc < 6) {
    printf("usage: %s <fastafile> <wtmxfile1> <motifweight> <windowsize> <shiftsize> [-od <output_dir>] [-b <background file>] [-m <Markov order>] [-mt <site percentile>] [-wc] [-name]\n",argv[0]);
    exit(1);
  }
	
  srandom((unsigned int)time(NULL));
  srand48((unsigned int)time(NULL));
	
  char *fastafile = argv[1];
  FastaFile *file = new FastaFile();
  file->ReadFasta(fastafile);
	
  Sequence **seqs = file->_sequences;
  int numSeqs = file->Size();
	
  char *wmc1file = argv[2];
  WtMxCollection *wmc1 = new WtMxCollection(wmc1file);
  if (wmc1->Size() != 1) { 
    printf("Can only scan for one motif at a time: file %s should have only one PWM\n");
    exit(1);
  }	
	
  float motifweight = atof(argv[3]);
  int windowsize = atoi(argv[4]);
  int shiftsize = atoi(argv[5]);
	
  // Read in the optional arguments
  int argbase = 6;
  struct Options *opt = ReadOptionalArguments(argbase, argc, argv);
	
  // create background, if required to be global
  WtMx *bkgwm = NULL;
  Sequence **bkg_seq = new Sequence *[1];
  if (opt->bkg_file != NULL) {
    bkg_seq[0] = new Sequence(opt->bkg_file);
    bkgwm = SequenceWtMxToolbox::TrainBackground(bkg_seq,1,opt->markov_order);
    delete bkg_seq[0];
  }
  delete [] bkg_seq;
	
  // is there a (re-pvalue) threshold applied on motif occurrences ?
  if (opt->motif_repval_threshold >= 0) { 
    for (int i=0; i<wmc1->Size(); i++) {
      WtMx *wm = wmc1->WM(i);
      float rethresh; float pval;
      wm->REPval2RE(opt->motif_repval_threshold, rethresh, pval);
      wm->SetREThresh(rethresh);
      wm->SetREPvalThresh(pval);
    }
  }

  // cache probabilities for each sequence
  // store local bkg pwms (after creating them) if needed
  for (int i=0; i<numSeqs; i++) {
    // fprintf(stderr,"Caching sequence %d\n",i);
    // SequenceWtMxToolbox::CacheSubsequenceProbabilities(seqs[i],wmc1,bkgwm,opt->markov_order);
  }
	
  // Open file for output
  FILE *ener = OpenOutput (fastafile, opt->output_dir);

  char *name = new char[1024];
  // process 
  Sequence **seq = new Sequence *[1];
  for (int seqnum=0; seqnum < numSeqs; seqnum++) {
    seq[0] = seqs[seqnum];		
    seq[0]->Name(name);

    SequenceWtMxToolbox::CacheSubsequenceProbabilities(seq[0],wmc1,bkgwm,opt->markov_order);

    int qlen = seq[0]->Length();
    bool lastwindow = false;
    // slide a window on the query sequence
    for (int window=0; ; window += shiftsize) {    
      if (lastwindow) break;
      int qstart = window;
      if (qstart >= qlen) break;
      int qstop = qstart + windowsize - 1;
      if (qstop >= qlen) {
	qstop = qlen-1;
	lastwindow = true;
	if (qstop-qstart+1 < MIN_WINDOW_LENGTH) break;
      }

      // have determined the start and stop coords
      // create the parameters object
      IndependentPairFreeEnergy *ipfe = new IndependentPairFreeEnergy(seq,1,wmc1,qstart,qstop);
      ipfe->SetGlobalWeight(motifweight);
      if (opt->weight_constraint) {
	ipfe->SetWeightConstraint();
      }
      DTYPE bestllr = -1; DTYPE besttpi = -1;
      ipfe->InitializeParameters(bkgwm, wmc1->Size()); // bkgwm may be NULL, in which case cached bkgwm will be used
      ipfe->SetPi(motifweight);
      DTYPE null_fen = ipfe->EvaluateFreeEnergy();		
      for (int f=1; f<=3; f++) {
	DTYPE p = f*motifweight;
	ipfe->SetPi(p);
	DTYPE llr = ipfe->Train(false);
	llr = null_fen - llr;
	DTYPE tpi;
	ipfe->GetPi(tpi);
	if (llr > bestllr) { bestllr = llr; besttpi = tpi; }
      }
      DTYPE p = 0.0025;
      if (p > 3*motifweight) {
	ipfe->SetPi(p);
	DTYPE llr = ipfe->Train(false);
	llr = null_fen - llr;
	DTYPE tpi;
	ipfe->GetPi(tpi);
	if (llr > bestllr) { bestllr = llr; besttpi = tpi; }
      }
      if (opt->name) 
	fprintf(ener,"%s\t%d\t%.2f\t%g\n",name,qstart,bestllr,besttpi);
      else 
	fprintf(ener,"%d\t%.2f\t%g\n",qstart,bestllr,besttpi);
      delete ipfe;
    }
    // clean up
    fprintf(stderr,"Done processing seq number %d\n",seqnum);
    SequenceWtMxToolbox::DeleteCacheSubsequenceProbabilities(seq[0]);		
  }
  delete [] name;
	
  fclose(ener);
}

