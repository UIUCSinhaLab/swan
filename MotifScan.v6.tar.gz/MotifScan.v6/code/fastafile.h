#ifndef _fastafile_h_
#define _fastafile_h_

#include "sequence.h"

#define MAX_NUM_SEQUENCES 1000000

class FastaFile {
public:
  Sequence *_sequences[MAX_NUM_SEQUENCES];
  int _numSequences;
  FastaFile();
  void ReadFasta(const char *filename);
  ~FastaFile();
  int Size();
  Sequence *operator[](int index);
};

#endif
