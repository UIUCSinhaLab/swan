#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Warn(const char *str)
{
	fprintf(stderr,str);
}

FILE *OpenProfile(char *file, char *output_dir)
{
	char filename[1024];
	if (output_dir != NULL) {
		strcpy(filename, output_dir);
		strcat(filename, "/");
		int len = strlen(file);
		int pos = len - 1;
		while (pos >= 0) {
			if (file[pos]=='/') break;
			pos--;
		}
		if (pos < 0) {
			strcat(filename,file);
		}
		else {
			strcat(filename, &(file[pos+1]));
		}
	}
	else {
		strcpy(filename,file);
	}
	strcat(filename,".prof");
	FILE *prof = fopen(filename,"w");
	return prof;
}

FILE *OpenOutput(char *file, char *output_dir)
{
	char filename[1024];
	if (output_dir != NULL) {
		strcpy(filename, output_dir);
		strcat(filename, "/");
		int len = strlen(file);
		int pos = len - 1;
		while (pos >= 0) {
			if (file[pos]=='/') break;
			pos--;
		}
		if (pos < 0) {
			strcat(filename,file);
		}
		else {
			strcat(filename, &(file[pos+1]));
		}
	}
	else {
		strcpy(filename,file);
	}
	strcat(filename,".fen");
	FILE *out = fopen(filename,"w");
	return out;
}

FILE *OpenDictionary(char *file, char *output_dir)
{
	char filename[1024];
	if (output_dir != NULL) {
		strcpy(filename, output_dir);
		strcat(filename, "/");
		int len = strlen(file);
		int pos = len - 1;
		while (pos >= 0) {
			if (file[pos]=='/') break;
			pos--;
		}
		if (pos < 0) {
			strcat(filename,file);
		}
		else {
			strcat(filename, &(file[pos+1]));
		}
	}
	else {
		strcpy(filename,file);
	}
	strcat(filename,".dict");
	FILE *dict = fopen(filename,"w");
	return dict;
}

void PrintParameters(char *seqfile, char *wmcfile, int windowsize, int shiftsize, struct Options *opt)
{
	char filename[1024];
	char *output_dir = opt->output_dir;
	if (output_dir != NULL) {
		strcpy(filename, output_dir);
		strcat(filename, "/");
		int len = strlen(seqfile);
		int pos = len - 1;
		while (pos >= 0) {
			if (seqfile[pos]=='/') break;
			pos--;
		}
		if (pos < 0) {
			strcat(filename,seqfile);
		}
		else {
			strcat(filename, &(seqfile[pos+1]));
		}
	}
	else {
		strcpy(filename,seqfile);
	}
	strcat(filename,".parameters");
	FILE *par = fopen(filename,"w");
	
	fprintf(par,"External Parameters\n\nsequence file: %s\nweight matrix file: %s\nwindow width: %d\nwindow shift: %d\nbackground file: %s\nfree energy threshold for profiling: %.2f\nMotif count threshold for profiling: %.2f\nMotif RE p-value threshold: %f\n",seqfile,wmcfile,windowsize,shiftsize,opt->bkg_file,opt->fen_threshold, opt->motif_occurrence_threshold,opt->motif_repval_threshold);
	fprintf(par,"\nInternal Parameters\n\nMARKOV_ORDER: %d (%d+1)-mers are counted\n\n",opt->markov_order, opt->markov_order);
	fclose(par);
}

struct Options *ReadOptionalArguments(int &argbase, int argc, char **argv)
{
	struct Options *opt = new struct Options;
	while (argbase < argc && argv[argbase][0]=='-') {
		if (!strcmp(argv[argbase],"-od")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -od must be followed by a path\n");
				exit(1);
			}
			opt->output_dir = argv[argbase];
			argbase++;
			continue;
		}    
		if (!strcmp(argv[argbase],"-wc")) {
			opt->weight_constraint = true;
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-score")) {
			opt->naive_score = true;
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-name")) {
			opt->name = true;
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-wl")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -wl must be followed by an integer\n");
				exit(1);
			}
			opt->swindowsize = atoi(argv[argbase]);
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-b")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -b must be followed by a file name\n");
				exit(1);
			}
			opt->bkg_file = argv[argbase];
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-sb")) {
			opt->separate_bkgs = true;
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-ft")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -ft must be followed by a number\n");
				exit(1);
			}
			opt->fen_threshold = atof(argv[argbase]);
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-mt")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -ot must be followed by a number\n");
				exit(1);
			}
			opt->motif_repval_threshold = atof(argv[argbase]);
			argbase++;
			continue;
		}
		
		if (!strcmp(argv[argbase],"-ot")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -ot must be followed by a number\n");
				exit(1);
			}
			opt->motif_occurrence_threshold = atof(argv[argbase]);
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-m")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -m must be followed by a number\n");
				exit(1);
			}
			opt->markov_order = atoi(argv[argbase]);      
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-phy")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -phy must be followed by a number\n");
				exit(1);
			}
			opt->phy = atof(argv[argbase]);    
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-phyb")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -phyb must be followed by a number\n");
				exit(1);
			}
			opt->phy_b = atof(argv[argbase]);    
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-OIP")) {
			opt->optimize_iteration_progress = true; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-trainpi")) {
			opt->equalpriors = false; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-trainphy")) {
			opt->trainphy = true; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-LLR")) {
			opt->llr = true; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-LLR2")) {
			opt->llr2 = true; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-alnpost")) {
			opt->alnpost = true; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-FILTERSTUBB")) {
			opt->filter_stubb = true; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-SIA")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -SIA must be followed by a number\n");
				exit(1);
			}
			opt->stop_iteration_threshold = atof(argv[argbase]); 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-fitprobs")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -fitprobs must be followed by a file\n");
				exit(1);
			}
			opt->fitprobsfile = argv[argbase]; 
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-numSeed")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -numSeed must be followed by a number\n");
				exit(1);
			}
			opt->numSeed = atoi(argv[argbase]);
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-window")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -window must be followed by a number\n");
				exit(1);
			}
			opt->window = atoi(argv[argbase]);
			argbase++;
			continue;
		}
		if (!strcmp(argv[argbase],"-viterbi")) {
			argbase++;
			if (argbase >= argc) {
				printf("Error: -viterbi must be followed by a path\n");
				exit(1);
			}
			opt->printV = argv[argbase];
			argbase++;
			continue;
		}    
		printf("Error: option %s not recognized\n",argv[argbase]);
		exit(1);
	}
	
	return opt;
}

