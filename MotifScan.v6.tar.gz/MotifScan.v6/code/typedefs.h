#ifndef _TYPEDEFS_H_
#define _TYPEDEFS_H_

typedef double DTYPE;
typedef double DDTYPE;

#endif

