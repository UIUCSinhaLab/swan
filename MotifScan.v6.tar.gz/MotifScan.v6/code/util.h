#ifndef _UTIL_H_
#define _UTIL_H_

#define MIN_WINDOW_LENGTH 200
#define MIN_SPEC_FRACTION 0.5

#include "SequenceWtMxToolbox.h"

struct Options {
  char *output_dir;
  char *bkg_file;
  bool  separate_bkgs;
  float fen_threshold;
  float motif_occurrence_threshold;
  int   markov_order;
  int   swindowsize;
  float stop_iteration_threshold;
  bool  optimize_iteration_progress;
  bool  filter_stubb;
  char *fitprobsfile;
  float phy;
  float phy_b;
  bool  equalpriors;
  bool  trainphy;
  bool  llr;
  bool  llr2;
  bool  alnpost;
  int   numSeed;
  int   window;
  char *printV;
  float motif_repval_threshold;
  bool  weight_constraint;
  bool  naive_score;
  bool  name;

  Options() { output_dir = NULL; bkg_file = NULL; separate_bkgs = false; fen_threshold = DEFAULT_FEN_THRESHOLD; motif_occurrence_threshold = DEFAULT_MOTIF_OCCURRENCE_THRESHOLD; markov_order = DEFAULT_MARKOV_ORDER; stop_iteration_threshold = 0; optimize_iteration_progress = false; fitprobsfile = NULL; filter_stubb = false; swindowsize = 0; phy = 0.5; phy_b = 0.5; equalpriors = true; trainphy = false; llr = false; llr2 = false; alnpost = false; numSeed = 1; window = -1; printV = NULL; motif_repval_threshold = -1; weight_constraint = false; naive_score = false; name = false; }
};

void Warn(const char *str);
FILE *OpenProfile(char *file, char *output_dir = NULL);
FILE *OpenOutput(char *file, char *output_dir = NULL);
FILE *OpenDictionary(char *file, char *output_dir = NULL);
void PrintParameters(char *seqfile, char *wmcfile, int windowsize, int shiftsize, struct Options *opt);
struct Options *ReadOptionalArguments(int &argbase, int argc, char **argv);

#endif
