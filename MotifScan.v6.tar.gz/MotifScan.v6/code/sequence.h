#ifndef _sequence_h_
#define _sequence_h_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include "wtmx.h"

class Sequence {
  char  *_seq;
  char  *_indexseq;        
  int   _length;
  int   _reallength;
  char  _name[1024];

  void  *_udata;

  char   *ReadFasta(FILE *fp);

 public:
  static const int MAX_LINE_LENGTH = 10000;
  static const int MAX_SEQ_LENGTH = 40000000;

  Sequence(char *flname);
  Sequence(char *seq, int length, char *name);
  ~Sequence();

  int   Length();
  int   RealLength();
  char  CharAt(int index);
  char  IndexOfCharAt(int index);
  bool  AmbiguousCharAt(int index);
  void  Print(int start, int stop);
  void  Name(char *name);

  void  SetUserData(void *udata);
  void  *GetUserData();

  void  ComputeBaseFrequencies(float *basef);
  void  ComputeBaseFrequenciesWithHistory(float **basef, int morder);

  bool  OccursAt(int pos, WtMx *wm, DTYPE *llrat=NULL);
  DTYPE SumLRatSites(WtMx *wm);
  DTYPE SumSiteStrength(WtMx *wm);

#ifdef _OPTIMIZE_PROTECTED_ACCESS
  friend class SequenceWtMxToolbox;
#endif
};

#endif


