#!/usr/bin/python


import sys, pdb


if len(sys.argv) < 4:
    print "{map file} {fasta file} {output fasta file}"
    sys.exit(0)

amel = []
dmel = []

f = open(sys.argv[1],'r').readlines()

for line in f:
    tokens = line.strip().split()
    amel.append(tokens[1])
    dmel.append(tokens[0])

f = open(sys.argv[2],'r')
out = open(sys.argv[3],'w')

header = ""
for line in f:
    if line[0] == '>':
        header = line.strip()[1:]
        if amel.count(header) == 0 and dmel.count(header) == 0:
            header = ""            
    else:
        if len(header) > 0:
            out.write(">" + header + "\n")
            out.write(line)
            header = ""

out.close()
f.close()
